from aiogram import Router, F
from aiogram.types import Message, PreCheckoutQuery

router = Router()

@router.pre_checkout_query()
async def pre_checkout(query: PreCheckoutQuery):
    await query.answer(ok=True)

@router.message(F.successful_payment)
async def successful_payment(message: Message):
    await message.answer(
        "🎉 <b>To'lov qabul qilindi!</b>\n\n"
        "👑 Siz endi <b>PREMIUM</b> foydalanuvchisiz!\n"
        "Barcha imkoniyatlar faollashtirildi. 🚀"
    )
