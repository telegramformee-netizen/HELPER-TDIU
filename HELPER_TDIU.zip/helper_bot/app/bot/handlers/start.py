from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery

from app.core.config import settings

router = Router()

def main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🚀 Mini App ni ochish",
                              url=settings.mini_app_url)],
        [InlineKeyboardButton(text="🔗 Hemis'ni ulash", callback_data="connect_hemis"),
         InlineKeyboardButton(text="👀 Demo rejim",     callback_data="demo_mode")],
        [InlineKeyboardButton(text="👑 Premium olish",  callback_data="buy_premium"),
         InlineKeyboardButton(text="⚙️ Sozlamalar",     callback_data="settings")],
    ])


@router.message(CommandStart())
async def cmd_start(message: Message):
    name = message.from_user.first_name
    await message.answer(
        f"🎓 Assalomu alaykum, <b>{name}</b>!\n\n"
        f"<b>HELPER (TDIU)</b> — TDIU talabalari uchun aqlli yordamchi!\n\n"
        f"<b>Nima qila oladi?</b>\n"
        f"📊 Baholar — Joriy, Oraliq va Yakuniy (grafik ko'rinishda)\n"
        f"📅 Haftalik dars jadvali\n"
        f"🔔 Har kuni 20:00 da ertangi jadval\n"
        f"⚠️ Qayta topshirish xavfini oldindan ko'ring\n"
        f"📍 NB (davomat) 20% chegarasi ogohlantirish\n"
        f"🗺️ Auditoriya va o'qituvchi navigator\n\n"
        f"<b>PREMIUM</b> (5,000 so'm/oy):\n"
        f"⚡ Baholar yangilanishi — darhol bildirishnoma\n"
        f"🔄 Jadval o'zgarganda — darhol ogohlantirish\n"
        f"📈 To'liq GPA analitika\n"
        f"🎯 Yakuniy imtihon uchun kerakli ball\n\n"
        f"👇 Boshlash uchun:",
        reply_markup=main_keyboard(),
    )


@router.callback_query(F.data == "connect_hemis")
async def cq_connect_hemis(callback: CallbackQuery):
    await callback.message.answer(
        "🔗 <b>Hemis'ni ulash</b>\n\n"
        "Mini App ichida <b>Kirish</b> tugmasini bosing va\n"
        "Hemis ID hamda parolingizni kiriting.\n\n"
        "🔐 Parolingiz AES-256 bilan shifrlanadi.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🚀 Mini App", url=settings.mini_app_url)
        ]])
    )
    await callback.answer()


@router.callback_query(F.data == "demo_mode")
async def cq_demo(callback: CallbackQuery):
    await callback.message.answer(
        "👀 <b>Demo rejim</b>\n\n"
        "Hemis ID yoki parol kerak emas.\n"
        "Namunali ma'lumotlar ko'rsatiladi.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="👀 Demo kirish",
                                 url=f"{settings.mini_app_url}?demo=1")
        ]])
    )
    await callback.answer()


@router.callback_query(F.data == "buy_premium")
async def cq_premium(callback: CallbackQuery):
    await callback.message.answer(
        "👑 <b>Premium obuna</b>\n\n"
        "💰 Narxi: <b>5,000 so'm / oy</b>\n\n"
        "✅ Darhol ball yangilanishi\n"
        "✅ Jadval o'zgarish ogohlantirishlari\n"
        "✅ To'liq GPA analitika\n"
        "✅ Yakuniy imtihon ball hisob-kitobi\n"
        "✅ O'qituvchi tracker\n"
        "✅ Reklamasiz\n\n"
        "To'lov tizimi tez kunda ulanadi! 🚀"
    )
    await callback.answer()


@router.callback_query(F.data == "settings")
async def cq_settings(callback: CallbackQuery):
    await callback.message.answer(
        "⚙️ <b>Sozlamalar</b>\n\n"
        "Tez kunda qo'shiladi..."
    )
    await callback.answer()
